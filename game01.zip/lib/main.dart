import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(MemoryGame());

class MemoryGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Memory Match Game',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.teal),
      home: WelcomePage(),
    );
  }
}

//this is homepage
class WelcomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF000000), Color(0xFF0f2027)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Memory Blast! 🧠",
                  style: TextStyle(
                    fontSize: 34,
                    fontWeight: FontWeight.bold,
                    color: Colors.tealAccent,
                    shadows: [
                      Shadow(
                        color: Colors.black,
                        offset: Offset(2, 2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 25),
                ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Image.network(
                    'https://i.ytimg.com/vi/XzD0PMRJfyk/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBKdCeeMXK_5ZDsuuAEFC2TYtlwMg',
                    height: 220,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "Match, Tap, Win! 🎯",
                  style: TextStyle(
                    color: Color(0xb3fffd49),
                    fontSize: 25,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 30),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => MemoryGamePage()),
                    );
                  },
                  icon: Icon(Icons.play_arrow),
                  label: Text("Start Game"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xff22cda2),
                    foregroundColor: Colors.black,
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                    textStyle:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 10,
                  ),
                ),
                SizedBox(height: 30),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.network(
                          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgIc1D5ZAdWxaTpgHvsVpXesDYgmdwaBK5TA&s',
                          height: 150,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.network(
                          'https://img.freepik.com/free-vector/cute-pug-dog-playing-vr-game-with-controller-cartoon-vector-icon-illustration-animal-technology_138676-13973.jpg?semt=ais_hybrid&w=740',
                          height: 150,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

//this is game page(memory page)
class MemoryGamePage extends StatefulWidget {
  @override
  _MemoryGamePageState createState() => _MemoryGamePageState();
}

class _MemoryGamePageState extends State<MemoryGamePage> {
  List<String> _emojis = ['🍎', '🍌', '🍇', '🍓', '🍉', '🍍', '🥝', '🍒'];
  List<bool> _revealed = List.filled(16, false);
  List<String> _shuffled = [];
  int? _firstIndex;
  bool _waiting = false;
  int _matchedPairs = 0;

  @override
  void initState() {
    super.initState();
    _startGame();
  }

  void _startGame() {
    _shuffled = List.from(_emojis)..addAll(_emojis);
    _shuffled.shuffle();
    _revealed = List.filled(16, false);
    _matchedPairs = 0;
    _firstIndex = null;
    setState(() {});
  }

  void _onTap(int index) {
    if (_waiting || _revealed[index]) return;

    setState(() {
      _revealed[index] = true;
    });

    if (_firstIndex == null) {
      _firstIndex = index;
    } else {
      if (_shuffled[_firstIndex!] == _shuffled[index]) {
        _matchedPairs++;
        _firstIndex = null;

        if (_matchedPairs == 8) {
          Future.delayed(Duration(milliseconds: 800), () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => GameWinPage()),
            );
          });
        }
      } else {
        _waiting = true;
        Timer(Duration(seconds: 1), () {
          setState(() {
            _revealed[_firstIndex!] = false;
            _revealed[index] = false;
            _firstIndex = null;
            _waiting = false;
          });
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.white),
        title: Text(
          'Memory Match 🧩💥',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: Image.network(
              'https://cdn-icons-png.flaticon.com/512/545/545674.png',
              width: 24,
              height: 24,
              color: Colors.white,
            ),
            onPressed: _startGame,
            tooltip: "Restart Game",
          ),
        ],
      ),
      body: Container(
        color: Colors.teal.shade50,
        child: Column(
          children: [
            SizedBox(height: 20),
            Expanded(
              flex: 3,
              child: GridView.builder(
                padding: EdgeInsets.all(16),
                itemCount: 16,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemBuilder: (context, index) => GestureDetector(
                  onTap: () => _onTap(index),
                  child: Container(
                    decoration: BoxDecoration(
                      color:
                          _revealed[index] ? Colors.teal : Colors.teal.shade300,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 4,
                          offset: Offset(2, 2),
                        )
                      ],
                    ),
                    child: Center(
                      child: Text(
                        _revealed[index] ? _shuffled[index] : '?',
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                "🧠 Keep going! Let's train \n our brain! Don'T give up! 🏆",
                style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Color(0xff311509)),
              ),
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        'https://img.freepik.com/free-vector/cute-astronaut-playing-vr-game-with-controller-cartoon-vector-icon-illustration-science-technology_138676-13977.jpg?semt=ais_hybrid&w=740',
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        'https://img.freepik.com/free-vector/joystick-game-sport-technology_138676-2045.jpg?semt=ais_hybrid&w=740',
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}

//this is final step-result page
class GameWinPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff0a0f0a),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('🎉 You Win!',
                style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
            SizedBox(height: 30),
            ElevatedButton(
              child: Text('Play Again 😢'),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => MemoryGamePage()),
                );
              },
            ),
            SizedBox(height: 10),
            TextButton(
              child: Text('Back to Home 🔙'),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => WelcomePage()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
